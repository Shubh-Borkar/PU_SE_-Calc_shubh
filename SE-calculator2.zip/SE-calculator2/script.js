const materialsList = document.getElementById("materialsList");
const laboursList = document.getElementById("laboursList");

const materialSection = document.getElementById("materialSection");
const labourSection = document.getElementById("labourSection");

const materialTotal = document.getElementById("materialTotal");
const labourTotal = document.getElementById("labourTotal");
const grandTotal = document.getElementById("grandTotal");

const tabMaterial = document.getElementById("tabMaterial");
const tabLabour = document.getElementById("tabLabour");
const slider = document.querySelector(".tab-slider");

function createError(element, msg) {
    let old = element.parentElement.querySelector(".error");
    if (old) old.remove();

    let err = document.createElement("div");
    err.className = "error";
    err.innerText = msg;
    element.parentElement.appendChild(err);
}

function clearErrors() {
    document.querySelectorAll(".error").forEach(e => e.remove());
}

function addInputRow(container, classes) {
    const row = document.createElement("div");
    row.className = "input-row";

    row.innerHTML = `
        <div class="input-box">
            <input type="text" class="${classes[0]}" placeholder="${classes[3]}">
        </div>
        <div class="input-box">
            <input type="text" class="${classes[1]}" placeholder="${classes[4]}">
        </div>
        <div class="input-box">
            <input type="text" class="${classes[2]}" placeholder="${classes[5]}">
        </div>
    `;

    container.appendChild(row);
}

document.getElementById("addMaterialBtn").onclick = () => {
    addInputRow(materialsList, ["m-name", "m-price", "m-qty", "Item", "Price", "Qty"]);
};

document.getElementById("addLabourBtn").onclick = () => {
    addInputRow(laboursList, ["l-name", "l-wage", "l-days", "Labour", "Wage", "Days"]);
};

// VALIDATION LOGIC
function validateInputs() {
    clearErrors();
    let valid = true;

    const nameFields = document.querySelectorAll(".m-name, .l-name");
    nameFields.forEach(field => {
        if (field.value.trim() === "") {
            createError(field, "Name cannot be empty");
            valid = false;
        } 
        else if (/\d/.test(field.value)) {
            createError(field, "Name cannot contain numbers");
            valid = false;
        }
    });

    const numberFields = document.querySelectorAll(".m-price, .m-qty, .l-wage, .l-days");
    numberFields.forEach(field => {
        if (field.value.trim() === "") {
            createError(field, "Field cannot be empty");
            valid = false;
        } 
        else if (!/^\d+(\.\d+)?$/.test(field.value)) {
            createError(field, "Only numbers allowed");
            valid = false;
        }
    });

    return valid;
}

document.getElementById("calculateBtn").onclick = () => {

    if (!validateInputs()) return;

    let mCost = 0;
    let lCost = 0;

    const mPrice = document.querySelectorAll(".m-price");
    const mQty = document.querySelectorAll(".m-qty");

    for (let i = 0; i < mPrice.length; i++) {
        mCost += (parseFloat(mPrice[i].value) || 0) * (parseFloat(mQty[i].value) || 0);
    }

    const lWage = document.querySelectorAll(".l-wage");
    const lDays = document.querySelectorAll(".l-days");

    for (let i = 0; i < lWage.length; i++) {
        lCost += (parseFloat(lWage[i].value) || 0) * (parseFloat(lDays[i].value) || 0);
    }

    materialTotal.innerText = "Material Cost: ₹" + mCost;
    labourTotal.innerText = "Labour Cost: ₹" + lCost;
    grandTotal.innerText = "Total: ₹" + (mCost + lCost);
};

// TAB SWITCHING (smooth)
tabMaterial.onclick = () => {
    tabMaterial.classList.add("active");
    tabLabour.classList.remove("active");
    slider.style.transform = "translateX(0%)";
    materialSection.classList.add("active");
    labourSection.classList.remove("active");
};

tabLabour.onclick = () => {
    tabLabour.classList.add("active");
    tabMaterial.classList.remove("active");
    slider.style.transform = "translateX(100%)";
    labourSection.classList.add("active");
    materialSection.classList.remove("active");
};
